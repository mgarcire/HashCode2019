///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Hello World,                                                                                                             //
//	                                                                                                                         //
//	please type the name of the file you want to read in the String called "fileName". It is necessary that it exists        //
//	and is placed in the "dataInput" folder. Once you run the program, an output file with the same name will be created     //
//	in the "dataOutput" folder. We hope you like the program.                                                                //
//                                                                                                                           //
// 	Cheers,                                                                                                                  //
//                                                                                                                           //
// 	MAGo Code Team.                                                                                                          //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

package utilities;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Main {
	
	private static final String ONE_SPACE = " ";
	private static String fileName = "example", inputFolderName = "dataInput/", outputFolderName = "dataOutput/", 
			inputFileExtension = ".in", outputFileExtension = ".out";

	public static void main(String[] args) {
		readFile(inputFolderName.concat(fileName).concat(inputFileExtension));
		
		// TODO - Algorithm.
		
		writeFile(outputFolderName.concat(fileName).concat(outputFileExtension));
	}
	
	private static void readFile(String filePath) {
		try {
			String [] data; // Array of strings that contains the different cells.
			
			// Open the file and read it.
			BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath));
			
			// Read the next line;
			data = bufferedReader.readLine().split(ONE_SPACE);
			
			// TODO - Assign values and continue reading.
			System.out.println(data[0]);
			
			// Close the file.
			bufferedReader.close();
			
		} catch (IOException e) {
			System.out.println("Error while reading the input file: " + e);
		}
	}
	
	// Method that writes the output file, creating it previously in case it does not exist.
	private static void writeFile(String filePath) {
		FileWriter file = null;
		PrintWriter printWriter = null;
		
		try {
			// Create the printer.
			file = new FileWriter(filePath);
			printWriter = new PrintWriter(file);
			
			// TODO - Create the output.
			String output = "";
			
			// Print the output in the file.
			printWriter.print(output);
		} catch (IOException e) {
			System.out.println("Error while writing the output file: " + e);
		} finally {
			try {
				printWriter.close();
				file.close();
			} catch (IOException e) {
				System.out.println("Error while closing the output file: " + e);
			}
		}
	}

}
